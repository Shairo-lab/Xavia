export default function ({ message }) {
    message.reply(message.threadID);
}
