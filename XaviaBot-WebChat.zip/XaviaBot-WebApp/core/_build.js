import "../cleanup.js";

import {} from "dotenv/config";
import { resolve as resolvePath } from "path";
import logger from "./var/modules/logger.js";

import startServer from "./dashboard/server/app.js";
import handleListen from "./handlers/listen.js";
import initializeVar from "./var/_init.js";
import { getLang, loadPlugins } from "./var/modules/loader.js";
import { createMockApi, registerSocket, unregisterSocket } from "./var/modules/mockApi.js";
import { XDatabase } from "./handlers/database.js";
import { Assets } from "./handlers/assets.js";

import crypto from "crypto";

process.stdout.write(String.fromCharCode(27) + "]0;" + "Xavia WebChat" + String.fromCharCode(7));

process.on("unhandledRejection", (reason, p) => {
    console.error(reason, "Unhandled Rejection at Promise", p);
});

process.on("uncaughtException", (err, origin) => {
    logger.error("Uncaught Exception: " + err + ": " + origin);
});

process.on("SIGINT", () => {
    logger.system("Shutting down...");
    global.shutdown();
});

process.on("SIGTERM", () => {
    logger.system("Shutting down...");
    global.shutdown();
});

process.on("SIGHUP", () => {
    logger.system("Shutting down...");
    global.shutdown();
});

await initializeVar();

async function start() {
    try {
        console.clear();
        logger.system("Variables loaded.");
        logger.system("Starting XaviaBot Web Chat Mode...");

        // Use mock API instead of Facebook login
        const api = createMockApi();
        global.api = api;
        global.botID = api.getCurrentUserID();

        logger.system(`Bot ID set to: ${global.botID}`);

        const xDatabase = new XDatabase(api, global.config.DATABASE);
        await xDatabase.init();

        new Assets();
        logger.system("Loading plugins...");
        await loadPlugins(xDatabase);

        const serverAdminPassword = getRandomPassword(8);
        startServer(serverAdminPassword);

        process.env.SERVER_ADMIN_PASSWORD = serverAdminPassword;

        await booting(api, xDatabase);
    } catch (err) {
        logger.error(err);
        return global.shutdown();
    }
}

global.listenerID = null;

/**
 * @param {import("./var/modules/mockApi.js").createMockApi} api
 * @param {xDatabase} xDatabase
 */
async function booting(api, xDatabase) {
    global.controllers = {
        Threads: xDatabase.threads,
        Users: xDatabase.users,
    };

    const newListenerID = generateListenerID();
    global.listenerID = newListenerID;

    // Get the event handler
    const webChatHandler = await handleListen(newListenerID, xDatabase);

    // This is called by the Socket.io server when a user sends a message
    global.handleWebMessage = async (fakeEvent) => {
        const { _socket, senderID } = fakeEvent;

        // Register this socket so replies go back to the right person
        if (_socket) {
            registerSocket(senderID, _socket);
            global.currentSenderID = senderID;

            _socket.on("disconnect", () => {
                unregisterSocket(senderID);
            });
        }

        // Feed the event into the existing bot pipeline
        await webChatHandler(null, fakeEvent);
    };

    logger.system("===========================================");
    logger.system("  XaviaBot Web Chat is READY!");
    logger.system("  Open your browser to chat with the bot");
    logger.system("===========================================");
}

function generateListenerID() {
    return Date.now() + crypto.randomBytes(4).toString("hex");
}

function getRandomPassword(length) {
    return crypto.randomBytes(length).toString("hex").slice(0, length);
}

start();
