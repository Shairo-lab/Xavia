import express from "express";
import path from "path";
import cors from "cors";
import helmet from "helmet";
import { createServer } from "http";
import { Server } from "socket.io";

import rateLimit from "express-rate-limit";
import { readFileSync } from "fs";
import logger from "../../var/modules/logger.js";

/**
 * @param {string} serverAdminPassword
 */
function startServer(serverAdminPassword) {
    const app = express();
    const httpServer = createServer(app);
    const port = process.env.PORT || 3000;

    const io = new Server(httpServer, {
        cors: { origin: "*", methods: ["GET", "POST"] }
    });

    global.io = io;

    app.use(express.json());
    app.use(express.static(path.resolve("core/dashboard/public")));
    app.use(cors());
    app.use(helmet({ contentSecurityPolicy: false }));
    app.use(rateLimit({ windowMs: 15 * 60 * 1000, max: 100 }));

    app.get("/", (req, res) => {
        res.sendFile(path.resolve("core/dashboard/public", "index.html"));
    });

    io.on("connection", (socket) => {
        logger.system(`[WEBCHAT] User connected: ${socket.id}`);

        socket.on("userMessage", (data) => {
            const { message, senderName } = data;
            if (!message) return;

            logger.custom(`[WEBCHAT] ${senderName || "User"}: ${message}`, "MSG");

            const fakeEvent = {
                type: "message",
                body: message,
                threadID: "webchat_thread_001",
                messageID: `msg_${Date.now()}`,
                senderID: socket.id,
                isGroup: false,
                mentions: {},
                attachments: [],
                timestamp: Date.now(),
                _socket: socket,
            };

            if (global.handleWebMessage) {
                global.handleWebMessage(fakeEvent);
            }
        });

        socket.on("disconnect", () => {
            logger.system(`[WEBCHAT] User disconnected: ${socket.id}`);
        });
    });

    app.use((req, res, next) => {
        if (req.headers["xva-access-token"] != serverAdminPassword)
            return res.status(401).send("Unauthorized");
        next();
    });

    app.put("/commands", (req, res) => {
        const { command } = req.body;
        if (!command) return res.status(400).send("Bad Request");
        const commands = ["help", "version"];
        if (!commands.includes(command)) return res.status(400).send("Bad Request");

        const returnData = {};
        switch (command) {
            case "help": returnData.commands = commands; break;
            case "version":
                returnData.version = JSON.parse(readFileSync(path.resolve("package.json"))).version;
                break;
            default: return res.status(400).send("Bad Request");
        }
        return res.status(200).json(returnData);
    });

    global.server = httpServer.listen(port, () => {
        logger.system(`[SERVER] Web chat server started on port ${port}`);
        logger.system(`[SERVER] Admin password: ${serverAdminPassword}`);
    });
}

export default startServer;
