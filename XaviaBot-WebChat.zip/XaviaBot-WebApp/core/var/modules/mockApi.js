/**
 * Mock Facebook API
 * Replaces @xaviabot/fca-unofficial so all plugins work
 * but messages go to the web chat instead of Facebook
 */

import logger from "./logger.js";

// Store active sockets by senderID so we can reply to the right person
const activeSockets = new Map();

export function registerSocket(senderID, socket) {
    activeSockets.set(senderID, socket);
}

export function unregisterSocket(senderID) {
    activeSockets.delete(senderID);
}

function sendToWebChat(threadID, senderID, message) {
    // Try to find the socket for this sender
    const socket = activeSockets.get(senderID);
    if (socket && socket.connected) {
        let botMessage = "";
        if (typeof message === "string") {
            botMessage = message;
        } else if (message && message.body) {
            botMessage = message.body;
        } else if (message && message.attachment) {
            botMessage = "[Attachment]";
        } else {
            botMessage = JSON.stringify(message);
        }

        socket.emit("botReply", {
            message: botMessage,
            timestamp: Date.now(),
            threadID,
        });
        logger.custom(`[WEBCHAT] Bot replied: ${botMessage}`, "REPLY");
    } else if (global.io) {
        // Fallback: broadcast to all
        let botMessage = typeof message === "string" ? message : (message?.body || "[message]");
        global.io.emit("botReply", {
            message: botMessage,
            timestamp: Date.now(),
            threadID,
        });
    }
}

export function createMockApi() {
    let _currentUserID = "bot_001";

    const api = {
        getCurrentUserID: () => _currentUserID,

        sendMessage: (message, threadID, callback, replyToMessage = null) => {
            // Find who to reply to - use global currentSenderID set during message handling
            const senderID = global.currentSenderID || threadID;
            sendToWebChat(threadID, senderID, message);
            if (typeof callback === "function") {
                callback(null, { messageID: `bot_msg_${Date.now()}` });
            }
        },

        setMessageReaction: (emoji, messageID, callback, reaction) => {
            if (typeof callback === "function") callback(null, {});
        },

        unsendMessage: (messageID, callback) => {
            if (typeof callback === "function") callback(null, {});
        },

        getUserInfo: (userIDs, callback) => {
            const ids = Array.isArray(userIDs) ? userIDs : [userIDs];
            const result = {};
            ids.forEach(id => {
                result[id] = {
                    name: id === _currentUserID ? "Bot" : "User",
                    firstName: id === _currentUserID ? "Bot" : "User",
                    vanity: "",
                    thumbSrc: "",
                    profileUrl: "",
                    gender: 1,
                    type: "user",
                    isFriend: false,
                    isBirthday: false,
                };
            });
            if (typeof callback === "function") callback(null, result);
        },

        getThreadInfo: (threadID, callback) => {
            const info = {
                threadID,
                threadName: "Web Chat",
                participantIDs: [_currentUserID],
                userInfo: [],
                nicknames: {},
                unreadCount: 0,
                messageCount: 0,
                imageSrc: null,
                timestamp: Date.now(),
                isGroup: false,
                adminIDs: [{ id: _currentUserID }],
                isSubscribed: true,
                folder: "INBOX",
                isArchived: false,
                cannotReplyReason: null,
                emoji: null,
                color: null,
                isReadOnly: false,
                eventReminders: [],
                joinableMode: { mode: 0, link: "" },
                reactionsMuteMode: "REACTIONS_NOT_MUTED",
                mentionsMuteMode: "MENTIONS_NOT_MUTED",
                isUnread: false,
                snippet: "",
                snippetAttachments: [],
                snippetSender: _currentUserID,
                lastReadTimestamp: Date.now(),
                hasEmailParticipant: false,
                readOnly: false,
                isSpam: false,
                messageTimestamp: Date.now(),
                messagesCount: 0,
                name: "Web Chat",
                members: [],
            };
            if (typeof callback === "function") callback(null, info);
        },

        getThreadList: (limit, timestamp, tags, callback) => {
            if (typeof callback === "function") callback(null, []);
        },

        setTitle: (newTitle, threadID, callback) => {
            if (typeof callback === "function") callback(null, {});
        },

        changeNickname: (newNickname, threadID, participantID, callback) => {
            if (typeof callback === "function") callback(null, {});
        },

        changeThreadColor: (color, threadID, callback) => {
            if (typeof callback === "function") callback(null, {});
        },

        changeThreadEmoji: (emoji, threadID, callback) => {
            if (typeof callback === "function") callback(null, {});
        },

        addUserToGroup: (userID, threadID, callback) => {
            if (typeof callback === "function") callback(null, {});
        },

        removeUserFromGroup: (userID, threadID, callback) => {
            if (typeof callback === "function") callback(null, {});
        },

        changeAdminStatus: (threadID, userID, adminStatus, callback) => {
            if (typeof callback === "function") callback(null, {});
        },

        markAsRead: (threadID, read, callback) => {
            if (typeof callback === "function") callback(null, {});
        },

        getAppState: () => ({}),

        listenMqtt: (callback) => {
            logger.system("[MOCKAPI] listenMqtt called — using web chat instead");
            return { stopListening: () => {} };
        },

        httpGet: (url, callback) => {
            if (typeof callback === "function") callback(new Error("Not supported in web mode"), null);
        },

        httpPost: (url, form, callback) => {
            if (typeof callback === "function") callback(new Error("Not supported in web mode"), null);
        },
    };

    return api;
}
